NABU Games (Image v1a) - Folder Version.

This is a small attempt to pull together (most) of the games (reported to work) under a set of folders for use with IshkurCPM under NNS.

It contains the following collection of NABU games and MSX rom files.

NABU Games (Native / Ported / Converted) are in - F1:
MSX Rom files (complete with MSX8) are in - F2:

You can copy these folders into the approriate NNS folder and they will be availabe as Drive "F:" User 1 & User 2.

Other information “txt” files can be found in the folders.

Reference Links:
https://github.com/GryBsh/NabuNetSim
https://github.com/linuxplayground/nabu-games
https://gtamp.com/nabu/
https://github.com/lesbird/MSX8
https://github.com/brijohn/nabupc

