NABU Games (Image v1a) - Labomb MAME Version.

This is a small attempt to pull together (most) of the games (reported to work) under Labomb's CP/M. All loaded onto a ready to run CP/M drive image.

It contains the following collection of NABU games and MSX rom files.

NABU Games (Ported / Converted) are in - Drive "B" - User 0:
MSX Rom files (complete with MSX8) are in - Drive "B" - User 1:
MSX8 Master files are in - Drive "B" - User 2:

These are located on the "stock" "labomb" MAME drives images with additional files added.

NABU_CPM22_HD_80_GAMES1.chd
NABU_CPM22_HD_GAMES1.chd

Other information “txt” files can be found in the folders.

Please see "labomb's" documentation for image details - https://github.com/labomb/NABU_PC_CPM_2.2/tree/master/mame_harddrive_images

Reference Links:
https://github.com/linuxplayground/nabu-games
https://gtamp.com/nabu/
https://github.com/lesbird/MSX8
https://github.com/brijohn/nabupc
https://github.com/labomb/NABU_PC_CPM_2.2
